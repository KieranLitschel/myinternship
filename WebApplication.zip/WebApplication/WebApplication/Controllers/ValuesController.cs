﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    [Route("getStatus")]
    public class ValuesController : Controller
    {
        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(string id)
        {
            Database db = new Database("database");
            CompanyAndStatus compAndStatus = db.getCompanyAndStatus();
            return Newtonsoft.Json.JsonConvert.SerializeObject(compAndStatus);
        }
    }

    public class CompanyAndStatus
    {
        public Dictionary<string, string> list;
    }
}
